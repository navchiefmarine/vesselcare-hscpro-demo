# VesselCare HSC Pro — ONGC-Aligned Marine Assurance v8.2

This package is ready for GitHub Pages.

## Free GitHub Pages deployment

1. Sign in to GitHub.
2. Create a new **Public** repository.
   Suggested name:
   `vesselcare-hsc-pro-demo`
3. Upload all files from this package to the **root** of the repository:
   - `index.html`
   - `.nojekyll`
   - `README.md`
4. Open:
   **Settings → Pages**
5. Under **Build and deployment** select:
   **Deploy from a branch**
6. Select:
   - Branch: `main`
   - Folder: `/ (root)`
7. Press **Save**.
8. Wait for GitHub Pages to publish the site.
9. Your link will normally look like:
   `https://YOUR-GITHUB-USERNAME.github.io/vesselcare-hsc-pro-demo/`

Send that HTTPS link directly to the customer by WhatsApp, email or SMS.

## Demo login

- User: `demo.master`
- Password: `demo123`
- Role: Master or another selectable demo role

## Important

This is an ONGC-aligned demonstration of marine-assurance and HSC operational-readiness workflows.
It is not an ONGC approval, statutory certificate, Class approval, or contract-specific acceptance.
